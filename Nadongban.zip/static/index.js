let date = new Date();
let global_data;

// 모달 가져오기
var modal = document.getElementById('myModal');
var span = document.getElementsByClassName('close')[0];

// 사용자가 <span> (x)를 클릭하면 모달 닫기
span.onclick = function() {
    modal.style.display = 'none';
}

// 사용자가 모달 바깥의 어떤 곳을 클릭하면 모달 닫기
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

function formatDateComponent(component) {
    return component < 10 ? `0${component}` : component;
}

function fetchMonthlyData() {
    const month = `${date.getFullYear()}-${formatDateComponent(date.getMonth() + 1)}`;
    fetch('/get-monthly-data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ month: month })
    })
    .then(response => response.json())
    .then(data => {
        updateSummarySection(data);
        drawChart(data);
    })
    .catch(error => {
        console.error('Error fetching monthly data:', error);
    });
}

document.addEventListener('DOMContentLoaded', function() {
    renderCalendar();
    fetchMonthlyData();
    highlightToday();
    setTimeout(checkDateData, 100); // renderCalendar 후 데이터 체크
});


function checkDateData() {
    let alcoholCount = 0;
    let exerciseCount = 0;
    let outsideCount = 0;

    const dates = Array.from(document.querySelectorAll('.date')).map(el => {
        const isCurrentMonth = el.querySelector('span').classList.contains('this');
        if (isCurrentMonth) {
            const dateData = el.getAttribute('data-date');
            const { alcohol, exercise, outside } = dateData;
            if (alcohol){
                alcoholCount++;
                console.log("음주 증가");
            } 
            if (exercise){
                exerciseCount++;
                console.log("운동 증가");
            } 
            if (outside) {
                outsideCount++;
                console.log("외출 증가");
            }
            return dateData;
        }
        return null;
    }).filter(date => date !== null);

    fetch('/check_date_data', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({dates})
    })
    .then(response => response.json())
    .then(data => {
        document.querySelectorAll('.date').forEach(dateElement => {
            const date = dateElement.getAttribute('data-date');
            const dateData = data[date];
            if (dateData && dateData.hasData) {
                if (dateData.alcohol && !dateData.exercise && !dateData.outside) {
                    dateElement.style.backgroundColor = 'hsl(0, 70%, 60%)'; // Red, high saturation
                } else if (dateData.alcohol && dateData.exercise) {
                    dateElement.style.backgroundColor = 'hsl(240, 50%, 50%)'; // Blue, medium saturation
                } else if (!dateData.alcohol) {
                    dateElement.style.backgroundColor = 'hsl(120, 40%, 50%)'; // Green, medium saturation
                } else {
                    dateElement.style.backgroundColor = 'hsl(180, 30%, 70%)'; // Default teal, low saturation
                }
            } else {
                dateElement.style.backgroundColor = 'white'; // 데이터가 없는 날
            }
        });
    })
    .catch(error => {
        console.error('Error checking data for dates:', error);
    });
}

function renderCalendar() {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    const prevLast = new Date(viewYear, viewMonth, 0);
    const thisLast = new Date(viewYear, viewMonth + 1, 0);

    const PLDate = prevLast.getDate();
    const PLDay = prevLast.getDay();
    const TLDate = thisLast.getDate();
    const TLDay = thisLast.getDay();

    const prevDates = [];
    const thisDates = [...Array(TLDate + 1).keys()].slice(1);
    const nextDates = [];

    // 이전 달의 날짜 계산
    for (let i = 0; i < PLDay + 1; i++) {
        prevDates.unshift(PLDate - i);
    }

    // 다음 달의 날짜 계산
    for (let i = 1; i < 7 - TLDay; i++) {
        nextDates.push(i);
    }

    const dates = prevDates.concat(thisDates, nextDates);
    const firstDateIndex = dates.indexOf(1);
    const lastDateIndex = dates.lastIndexOf(TLDate);

    document.querySelector('.year-month').textContent = `${viewYear}년 ${formatDateComponent(viewMonth + 1)}월`;
    const datesElement = document.querySelector('.dates');
    datesElement.innerHTML = '';

    dates.forEach((date, i) => {
        const dateElement = document.createElement('div');
        dateElement.classList.add('date');
        let actualMonth = viewMonth + 1; // 현재 달 기준
        if (i < firstDateIndex) actualMonth = viewMonth; // 이전 달
        if (i > lastDateIndex) actualMonth = viewMonth + 2; // 다음 달
        const formattedDate = `${viewYear}-${formatDateComponent(actualMonth)}-${formatDateComponent(date)}`;
        dateElement.setAttribute('data-date', formattedDate);

        const spanElement = document.createElement('span');
        spanElement.textContent = date;
        spanElement.classList.add(i >= firstDateIndex && i <= lastDateIndex ? 'this' : 'other');
        dateElement.appendChild(spanElement);
        datesElement.appendChild(dateElement);

        dateElement.addEventListener('click', function() {
            modal.style.display = 'block';
            fetchHealthInfo(formattedDate);
        });
    });
}

function showLoadingPopup() {
    document.getElementById('popup').style.display = 'block';
}

function highlightToday() {
    const today = new Date();
    const formattedToday = `${today.getFullYear()}-${(today.getMonth() + 1).toString().padStart(2, '0')}-${today.getDate().toString().padStart(2, '0')}`;

    // Assuming each date cell in your calendar has a 'data-date' attribute and a class 'date'
    const dateElements = document.querySelectorAll('.date');

    dateElements.forEach(el => {
        if (el.getAttribute('data-date') === formattedToday) {
            el.style.color = 'yellow'; // Set the background color to yellow
        }
    });
}

// 팝업을 숨기는 함수
function hideLoadingPopup() {
    document.getElementById('popup').style.display = 'none';
}

function fetchDataAndUpdate() {
    showLoadingPopup(); // 작업이 진행 중임을 알림
    fetch('/process_voice_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: '음성 입력 시작' })
        })
        
        .then(response => response.json())
        .then(data => {
            popupParagraph.textContent = '분석 중입니다.';
            global_data = data;
            updateCalendarWithData(data); // 서버 응답이 있을 경우 달력을 업데이트합니다.
            hideLoadingPopup(); // 성공적으로 데이터를 받아 팝업을 닫음
        })
        .catch(error => {
            console.error('Error:', error);
            hideLoadingPopup(); // 오류 발생 시 팝업을 닫음
        })
        .finally(() => {
            window.location.reload(true); // 모든 처리가 끝난 후 페이지 새로고침, 캐시 무시
            // ID가 "popup"인 div 안의 p 요소를 선택합니다.
        var popupParagraph = document.querySelector('#popup p');

        // 선택한 요소의 내부 텍스트를 변경합니다.
        popupParagraph.textContent = '말씀을 시작해주세요!';
                });
}

function drawChart(data) {
    const ctx = document.getElementById('activityChart').getContext('2d');
    console.log('음주 횟수:', data.alcohol, typeof data.alcohol);
    console.log('외출 횟수:', data.outside, typeof data.outside);
    console.log('운동 횟수:', data.exercise, typeof data.exercise);
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['음주 횟수', '외출 횟수', '운동 횟수'],
            datasets: [{
                label: '', // 빈 문자열로 설정하여 범례 제목을 비워놓음
                data: [data.alcohol, data.outside, data.exercise],
                backgroundColor: [
                    'rgba(255, 99, 132)',
                    'rgba(54, 162, 235)',
                    'rgba(75, 192, 192)'
                ],
                borderColor: [
                    'rgba(255, 99, 132)',
                    'rgba(54, 162, 235)',
                    'rgba(75, 192, 192)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            plugins: {
                legend: {
                    display:false
                }
            },
            scales: {
                y: { // 'yAxes' 대신 'y'를 사용
                    ticks: {
                        beginAtZero: true,
                        stepSize: 1, // 막대가 0부터 1단위로 올라가도록 stepSize 조정
                        color: 'black' // 글자 색상을 검은색으로 설정
                    }
                },
                x: { // X축 설정
                    ticks: {
                        color: 'black' // X축 글자 색상을 검은색으로 설정
                    }
                }
            }
        }
    });
}





function fetchHealthInfo(selectedDate) {
    // 주의: URL 경로를 Flask 라우트 경로에 맞게 수정하세요.
    fetch('/process_selected_date?date=' + selectedDate)
    .then(response => response.json())
    .then(data => {
        if (data) {
            // 모달 창에 데이터 표시
            document.getElementById('date-info').innerText = "날짜: " + selectedDate;
            document.getElementById('exercise-info').innerText = "운동 여부: " + (data.exercise ? "예" : "아니오");
            document.getElementById('outside-info').innerText = "외출 여부: " + (data.outside ? "예" : "아니오");
            document.getElementById('alcohol-info').innerText = "음주 여부: " + (data.alcohol ? "예" : "아니오");
            document.getElementById('content-info').innerText = "답변 내용: " + (data.content);

            // 모달 창 열기
            openModal();
        } else {
            alert('데이터를 찾을 수 없습니다.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('데이터를 가져오는 중 오류가 발생했습니다.');
    });
}

function updateSummarySection(data) {
    console.dir(data, { depth: null });
    let drinkCount = 0;
    let outsideCount = 0;
    let exerciseCount = 0;
    

    const alcoholValue = data.alcohol;
    const exerciseValue = data.exercise;
    const outsideValue = data.outside;
    document.getElementById('drink-count').textContent = alcoholValue;
    document.getElementById('outside-count').textContent = outsideValue;
    document.getElementById('exercise-count').textContent = exerciseValue;
}

function updateCalendarWithData(data) {
    const viewYear = date.getFullYear();
    const viewMonth = date.getMonth();

    // 데이터 포맷 변경
    const formattedData = data.reduce((acc, item) => {
        const formattedDate = `${viewYear}-${viewMonth + 1}-${formatDateComponent(item.date)}`;
        if (!acc.find(d => d.date === formattedDate)) { // 중복 방지를 위해 같은 날짜가 이미 있는지 체크
            acc.push({
                ...item,
                date: formattedDate
            });
        }
        return acc;
    }, []);

    const dates = document.querySelectorAll('.date');
    dates.forEach(dateElement => {
        const dataDate = dateElement.getAttribute('data-date');
        const dayData = formattedData.find(d => d.date === dataDate);
        if (dayData) {
            if (dayData.answered) {
                dateElement.classList.add('answered');  // 데이터 있음 (파랑색)
            } else {
                dateElement.classList.add('unanswered');  // 데이터 없음 (주황색)
            }
        } else {
            dateElement.classList.add('unanswered');  // 데이터 없음 (주황색)
        }
    });
}

function openModal() {
    document.getElementById('myModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('myModal').style.display = 'none';
}

span.onclick = function() {
    modal.style.display = 'none';
};

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
};

