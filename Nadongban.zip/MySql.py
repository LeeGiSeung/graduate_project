import pymysql 
from datetime import date

# conn = pymysql.connect(host='localhost', user='LeeGiSeung', password='Hh134679852!', db="Health", charset='utf8') 

conn = pymysql.connect(host='ls-94e556626c88eb365a7ec359470d1d33f56b67c1.ch0q0mic69gt.ap-northeast-2.rds.amazonaws.com', user='dbmasteruser', password='QNx87|udqkmuNTRN>%i1aaI*^9t<D1.s', db="nadongban", charset='utf8') 
cursor = conn.cursor() 

# 테이블 생성 부분 주석 처리
# sql = "CREATE TABLE Health (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, Alcohol INT, Outside INT, Exercise INT, Today DATE, Content VARCHAR(255));"
# cursor.execute(sql)

# 새로운 레코드 추가
insert_sql = "INSERT INTO Health (Alcohol, Outside, Exercise, Today, Content) VALUES (1, 1, 1, %s, %s);"
cursor.execute(insert_sql, ("2024-05-07", "오늘 아침일찍 일어나서 오랜만에 아침식사도 하고 헬스장 가서 운동도 했어"))
conn.commit()

# 테이블 내용 제거
# Delete_sql = "DROP TABLE Health;"
# cursor.execute(Delete_sql)

# 테이블 내용 확인
# select_sql = "SELECT * FROM Health;"
# cursor.execute(select_sql)

# 결과 가져오기
rows = cursor.fetchall()

# 가져온 결과 출력
for row in rows:
    print(row)

conn.close()
